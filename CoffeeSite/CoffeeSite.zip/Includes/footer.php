<footer>
    <p>All rights reserved</p>
</footer>
