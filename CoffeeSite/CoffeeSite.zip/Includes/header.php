<?php 
if(!isset($_SESSION)){session_start();}
// function console_log( $data ){
//     echo '<script>';
//     echo 'console.log('. json_encode( $data ) .')';
//     echo '</script>';
//   }
?>
<head>
    <meta http-equiv="content-type" content="text/html"; charset="utf-8" />
    <title>Brent's Coffee</title>
    <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
</head>